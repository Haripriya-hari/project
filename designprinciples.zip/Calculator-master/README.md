# Calculator
This is a program to implement Calculator keeping in mind SOLID,KISS,DRY,YAGNI principles.It does contain exception for any arithmetic operation.
